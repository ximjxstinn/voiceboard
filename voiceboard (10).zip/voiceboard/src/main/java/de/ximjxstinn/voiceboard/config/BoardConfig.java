package de.ximjxstinn.voiceboard.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import de.ximjxstinn.voiceboard.VoiceBoardClient;
import de.ximjxstinn.voiceboard.audio.FilterSettings;
import de.ximjxstinn.voiceboard.audio.FilterType;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Alle Einstellungen der Mod, gespeichert als config/voiceboard.json.
 */
public class BoardConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    /** Lautstärke aller Sounds für die anderen Spieler (0-100). */
    public int masterVolume = 70;
    /** Ob du deine eigenen Sounds lokal mithörst. */
    public boolean hearSelf = true;
    /** Lautstärke beim Mithören (0-100). */
    public int monitorVolume = 50;
    /** Taste für "Alle Sounds stoppen". */
    public KeyBind stopAllKey = new KeyBind();
    /** Ob Sounds auch gesendet werden, wenn das Mikrofon stumm ist. */
    public boolean playWhileMuted = true;
    /** Anzeige unten links, solange ein Sound läuft. */
    public boolean showHud = true;

    public FilterType filter = FilterType.NONE;
    /** Hauptschalter für den Voicefilter (der gewählte Filter bleibt gespeichert). */
    public boolean filterEnabled = true;
    /** Taste zum Ein-/Ausschalten des Voicefilters. */
    public KeyBind filterToggleKey = new KeyBind();
    /** Stärke des Voicefilters (0-100). */
    public int filterStrength = 100;
    /** Einstellungen der einzelnen Filter. */
    public FilterSettings filterSettings = new FilterSettings();

    public List<SoundEntry> sounds = new ArrayList<>();

    private transient boolean dirty;

    public static class SoundEntry {
        public String file;
        public String name;
        public int volume = 100;
        /** Sound endlos wiederholen. */
        public boolean loop;
        public KeyBind key = new KeyBind();

        public SoundEntry() {
        }

        public SoundEntry(String file, String name) {
            this.file = file;
            this.name = name;
        }
    }

    /** Eine Tastenbelegung, gespeichert als Typ-Name + Tastencode. */
    public static class KeyBind {
        public String type;
        public int code = -1;

        public boolean isBound() {
            return type != null && code != -1;
        }

        public void clear() {
            type = null;
            code = -1;
        }
    }

    public static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("voiceboard.json");
    }

    public static Path soundFolder() {
        return FabricLoader.getInstance().getGameDir().resolve("voiceboard").resolve("sounds");
    }

    public static BoardConfig load() {
        Path path = file();
        BoardConfig config = null;
        if (Files.exists(path)) {
            try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
                config = GSON.fromJson(reader, BoardConfig.class);
            } catch (Exception e) {
                VoiceBoardClient.LOGGER.error("Konnte {} nicht lesen, benutze Standardwerte", path, e);
            }
        }
        if (config == null) {
            config = new BoardConfig();
        }
        config.sanitize();
        try {
            Files.createDirectories(soundFolder());
        } catch (Exception e) {
            VoiceBoardClient.LOGGER.error("Konnte Sound-Ordner nicht anlegen", e);
        }
        return config;
    }

    private void sanitize() {
        if (sounds == null) sounds = new ArrayList<>();
        sounds.removeIf(s -> s == null || s.file == null);
        for (SoundEntry s : sounds) {
            if (s.name == null || s.name.isBlank()) s.name = stripExtension(s.file);
            if (s.key == null) s.key = new KeyBind();
            s.volume = clamp(s.volume);
        }
        if (stopAllKey == null) stopAllKey = new KeyBind();
        if (filterToggleKey == null) filterToggleKey = new KeyBind();
        if (filter == null) filter = FilterType.NONE;
        if (filterSettings == null) filterSettings = new FilterSettings();
        filterSettings.sanitize();
        masterVolume = clamp(masterVolume);
        monitorVolume = clamp(monitorVolume);
        filterStrength = clamp(filterStrength);
    }

    private static int clamp(int v) {
        return Math.max(0, Math.min(100, v));
    }

    public static String stripExtension(String file) {
        int dot = file.lastIndexOf('.');
        return dot > 0 ? file.substring(0, dot) : file;
    }

    /** Fügt eine Datei als Sound hinzu, falls sie noch nicht in der Liste ist. */
    public void addSound(String file) {
        if (!contains(file)) {
            sounds.add(new SoundEntry(file, stripExtension(file)));
        }
    }

    /** Der Filter, der gerade wirklich angewendet wird. */
    public FilterType activeFilter() {
        return filterEnabled ? filter : FilterType.NONE;
    }

    public boolean contains(String file) {
        for (SoundEntry s : sounds) {
            if (s.file.equals(file)) return true;
        }
        return false;
    }

    public void markDirty() {
        dirty = true;
    }

    public void saveIfDirty() {
        if (dirty) save();
    }

    public void save() {
        dirty = false;
        Path path = file();
        try {
            Files.createDirectories(path.getParent());
            try (Writer writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
                GSON.toJson(this, writer);
            }
        } catch (Exception e) {
            VoiceBoardClient.LOGGER.error("Konnte {} nicht speichern", path, e);
        }
    }
}
