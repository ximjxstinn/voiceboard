package de.ximjxstinn.voiceboard;

/** Einstieg einer versionsspezifischen Client-Variante. */
public interface VersionClient {

    void init();
}
