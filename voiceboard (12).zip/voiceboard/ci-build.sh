#!/usr/bin/env bash
# Baut VoiceBoard für alle Minecraft-Versionen und legt die Jars in out/.
set -eu
cd "$(dirname "$0")"
gradle clean build --stacktrace
mkdir -p out
cp build/libs/*.jar out/
echo "Fertige Jars:"; ls -1 out
