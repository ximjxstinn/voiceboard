package de.ximjxstinn.voiceboard.client.gui;

import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.network.chat.Component;

import java.util.function.IntConsumer;

/** Schieberegler von 0 bis 100 %. */
public class PercentSlider extends AbstractSliderButton {

    private final String label;
    private final IntConsumer onChange;

    public PercentSlider(int x, int y, int width, int height, String label, int percent, IntConsumer onChange) {
        super(x, y, width, height, Component.empty(), percent / 100.0);
        this.label = label;
        this.onChange = onChange;
        updateMessage();
    }

    private int percent() {
        return (int) Math.round(value * 100.0);
    }

    @Override
    protected void updateMessage() {
        String prefix = label == null || label.isEmpty() ? "" : label + ": ";
        setMessage(Component.literal(prefix + percent() + " %"));
    }

    @Override
    protected void applyValue() {
        if (onChange != null) {
            onChange.accept(percent());
        }
    }
}
