package de.ximjxstinn.voiceboard.gui;

import de.ximjxstinn.voiceboard.VoiceBoardClient;
import de.ximjxstinn.voiceboard.config.BoardConfig;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;

/**
 * Kleine Anzeige unten links, solange Soundboard-Sounds laufen:
 * die Musiknote neben dem Mikrofon-Symbol.
 */
public final class PlayingHud {

    private static final Identifier NOTE = Identifier.fromNamespaceAndPath("voiceboard", "icons/soundboard_button");

    private PlayingHud() {
    }

    public static void render(GuiGraphicsExtractor g, DeltaTracker deltaTracker) {
        BoardConfig config = VoiceBoardClient.config();
        if (config == null || !config.showHud) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return;
        }
        if (!VoiceBoardClient.player().hasActive()) {
            return;
        }
        int screenH = mc.getWindow().getGuiScaledHeight();

        // Rechts neben dem Mikrofon-Symbol von Simple Voice Chat (gleiche Höhe: 16 px über dem unteren Rand)
        g.blitSprite(RenderPipelines.GUI_TEXTURED, NOTE, 34, screenH - 32, 16, 16);
    }

}
