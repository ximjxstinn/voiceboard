#!/usr/bin/env bash
# Baut VoiceBoard für alle Minecraft-Versionen in versions/ und sammelt die Jars in out/.
# Schlägt eine Version fehl, werden die anderen trotzdem gebaut.
set -u
cd "$(dirname "$0")"
mkdir -p out
failed=()
for f in versions/*.properties; do
  v=$(basename "$f" .properties)
  echo "::group::Minecraft $v"
  if gradle clean build --stacktrace -Pmcver="$v"; then
    for jar in build/libs/*.jar; do
      case "$jar" in *-sources.jar) ;; *) cp "$jar" out/ ;; esac
    done
  else
    failed+=("$v")
  fi
  echo "::endgroup::"
done
echo "Fertige Jars:"; ls -1 out
if [ ${#failed[@]} -gt 0 ]; then
  echo "::error::Fehlgeschlagen für: ${failed[*]}"
  exit 1
fi
