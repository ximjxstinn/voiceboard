#!/usr/bin/env bash
# Baut VoiceBoard (eine Jar für Minecraft 26.1 bis 26.3) und legt sie in out/.
set -eu
cd "$(dirname "$0")"
mkdir -p out
gradle clean build --stacktrace
for jar in build/libs/*.jar; do
  case "$jar" in *-sources.jar) ;; *) cp "$jar" out/ ;; esac
done
echo "Fertige Jar:"; ls -1 out
