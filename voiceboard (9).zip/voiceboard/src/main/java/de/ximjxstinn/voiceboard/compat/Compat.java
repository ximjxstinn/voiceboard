package de.ximjxstinn.voiceboard.compat;

import com.mojang.blaze3d.platform.InputConstants;
import de.ximjxstinn.voiceboard.VoiceBoardClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Eine Jar für Minecraft 26.1, 26.2 und 26.3.
 * <p>
 * Die drei Versionen unterscheiden sich für VoiceBoard nur an zwei Stellen.
 * Seit 26.1 ist Minecraft nicht mehr verschleiert, deshalb können wir beim Start
 * per Reflection nachsehen, welche Variante vorhanden ist:
 * <ul>
 *     <li>Menüs: 26.1 nutzt {@code Minecraft.screen}/{@code Minecraft.setScreen},
 *     ab 26.2 gibt es {@code Minecraft.gui.screen()}/{@code gui.setScreen()}.</li>
 *     <li>Tasten: 26.1/26.2 nutzen GLFW ({@code isKeyDown(Window, int)}),
 *     26.3 nutzt SDL ({@code isKeyDown(int)}).</li>
 * </ul>
 */
public final class Compat {

    private static final int GLFW_KEY_J = 74;
    private static final int SDL_SCANCODE_J = 13;

    // Menüs ab 26.2
    private static Field guiField;
    private static Method guiScreen;
    private static Method guiSetScreen;
    // Menüs in 26.1
    private static Field mcScreen;
    private static Method mcSetScreen;
    // Tasten
    private static Method keyDownNew;   // 26.3: isKeyDown(int)
    private static Method keyDownOld;   // 26.1/26.2: isKeyDown(Window, int)

    static {
        try {
            guiField = Minecraft.class.getField("gui");
            Class<?> gui = guiField.getType();
            guiScreen = gui.getMethod("screen");
            guiSetScreen = gui.getMethod("setScreen", Screen.class);
        } catch (Exception e) {
            guiScreen = null;
            guiSetScreen = null;
        }
        if (guiScreen == null) {
            try {
                mcScreen = Minecraft.class.getField("screen");
                mcSetScreen = Minecraft.class.getMethod("setScreen", Screen.class);
            } catch (Exception e) {
                VoiceBoardClient.LOGGER.error("VoiceBoard: Menü-Funktionen dieser Minecraft-Version nicht gefunden", e);
            }
        }
        for (Method m : InputConstants.class.getMethods()) {
            if (!m.getName().equals("isKeyDown") || m.getReturnType() != boolean.class) continue;
            Class<?>[] p = m.getParameterTypes();
            if (p.length == 1 && p[0] == int.class) keyDownNew = m;
            if (p.length == 2 && p[1] == int.class) keyDownOld = m;
        }
        VoiceBoardClient.LOGGER.info("VoiceBoard: {} Menüs, {} Tasten",
                guiScreen != null ? "neue (26.2+)" : "alte (26.1)",
                keyDownNew != null ? "SDL (26.3+)" : "GLFW (26.1/26.2)");
    }

    private Compat() {
    }

    public static Screen screen(Minecraft mc) {
        try {
            if (guiScreen != null) return (Screen) guiScreen.invoke(guiField.get(mc));
            if (mcScreen != null) return (Screen) mcScreen.get(mc);
        } catch (Exception e) {
            VoiceBoardClient.LOGGER.error("VoiceBoard: aktuelles Menü nicht lesbar", e);
        }
        return null;
    }

    public static void setScreen(Minecraft mc, Screen screen) {
        try {
            if (guiSetScreen != null) {
                guiSetScreen.invoke(guiField.get(mc), screen);
            } else if (mcSetScreen != null) {
                mcSetScreen.invoke(mc, screen);
            }
        } catch (Exception e) {
            VoiceBoardClient.LOGGER.error("VoiceBoard: Menü konnte nicht geöffnet werden", e);
        }
    }

    /** Standardtaste zum Öffnen des Menüs (J). */
    public static int defaultOpenKey() {
        return keyDownNew != null ? SDL_SCANCODE_J : GLFW_KEY_J;
    }

    public static boolean isKeyDown(int code) {
        try {
            if (keyDownNew != null) return (boolean) keyDownNew.invoke(null, code);
            if (keyDownOld != null) return (boolean) keyDownOld.invoke(null, Minecraft.getInstance().getWindow(), code);
        } catch (Exception e) {
            // Taste nicht abfragbar -> als nicht gedrückt behandeln
        }
        return false;
    }
}
