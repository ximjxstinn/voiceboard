package de.ximjxstinn.voiceboard;

import com.mojang.blaze3d.platform.InputConstants;
import de.ximjxstinn.voiceboard.audio.LocalMonitor;
import de.ximjxstinn.voiceboard.audio.SoundPlayer;
import de.ximjxstinn.voiceboard.config.BoardConfig;
import de.ximjxstinn.voiceboard.gui.BoardScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import org.lwjgl.sdl.SDLScancode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.IdentityHashMap;
import java.util.Map;

public class VoiceBoardClient implements ClientModInitializer {

    public static final String MOD_ID = "voiceboard";
    public static final Logger LOGGER = LoggerFactory.getLogger("VoiceBoard");

    private static BoardConfig config;
    private static final SoundPlayer PLAYER = new SoundPlayer();
    private static final LocalMonitor MONITOR = new LocalMonitor();

    private static KeyMapping openKey;
    private final Map<BoardConfig.KeyBind, Boolean> wasDown = new IdentityHashMap<>();
    private int saveTimer;

    @Override
    public void onInitializeClient() {
        config = BoardConfig.load();

        KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(MOD_ID, "voiceboard"));
        openKey = KeyMappingHelper.registerKeyMapping(new KeyMapping("key.voiceboard.open", SDLScancode.SDL_SCANCODE_J, category));

        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    private void onTick(Minecraft mc) {
        while (openKey.consumeClick()) {
            if (mc.gui.screen() == null) {
                mc.gui.setScreen(new BoardScreen());
            }
        }

        // Hotkeys nur, wenn kein Menü/Chat offen ist (sonst würde Tippen Sounds auslösen)
        if (mc.gui.screen() == null && mc.player != null) {
            if (pressed(config.stopAllKey)) {
                PLAYER.stopAll();
            }
            for (BoardConfig.SoundEntry sound : config.sounds) {
                if (pressed(sound.key)) {
                    PLAYER.toggle(sound);
                }
            }
        } else {
            wasDown.clear();
        }

        if (++saveTimer >= 40) {
            saveTimer = 0;
            config.saveIfDirty();
        }
    }

    /** True genau in dem Tick, in dem die Taste heruntergedrückt wird. */
    private boolean pressed(BoardConfig.KeyBind bind) {
        if (!bind.isBound() || "MOUSE".equals(bind.type)) {
            return false;
        }
        boolean down = InputConstants.isKeyDown(bind.code);
        Boolean before = wasDown.put(bind, down);
        return down && (before == null || !before);
    }

    /** Anzeigename einer Tastenbelegung, z. B. "F13". */
    public static Component keyName(BoardConfig.KeyBind bind) {
        if (!bind.isBound()) {
            return Component.literal("Nicht belegt");
        }
        try {
            return InputConstants.Type.valueOf(bind.type).getOrCreate(bind.code).getDisplayName();
        } catch (Exception e) {
            return Component.literal("Taste " + bind.code);
        }
    }

    public static void notifyPlayer(String message) {
        Minecraft mc = Minecraft.getInstance();
        mc.execute(() -> {
            if (mc.player != null) {
                mc.player.sendOverlayMessage(Component.literal(message));
            }
        });
    }

    public static BoardConfig config() {
        return config;
    }

    public static SoundPlayer player() {
        return PLAYER;
    }

    public static LocalMonitor monitor() {
        return MONITOR;
    }
}
