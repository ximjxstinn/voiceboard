package de.ximjxstinn.voiceboard.gui;

import com.mojang.blaze3d.platform.InputConstants;
import de.ximjxstinn.voiceboard.VoiceBoardClient;
import de.ximjxstinn.voiceboard.audio.AudioLoader;
import de.ximjxstinn.voiceboard.audio.FilterType;
import de.ximjxstinn.voiceboard.audio.SoundPlayer;
import de.ximjxstinn.voiceboard.config.BoardConfig;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

/**
 * Hauptmenü mit den Reitern Soundeffekte, Voicefilter und Bibliothek.
 */
public class BoardScreen extends Screen {

    private enum Tab {
        SOUNDS("Soundeffekte"), FILTER("Voicefilter"), LIBRARY("Bibliothek");

        final String label;

        Tab(String label) {
            this.label = label;
        }
    }

    private static final int NONE = -1;
    private static final int STOP_ALL = -2;
    private static final int GRAY = 0xFFA0A0A0;
    private static final int WHITE = 0xFFFFFFFF;

    private static Tab lastTab = Tab.SOUNDS;

    private Tab tab = lastTab;
    private int scroll;
    private int listening = NONE;

    private int left;
    private int panelWidth;
    private int top;
    private int activeTabX;
    private int activeTabWidth;

    private final List<Label> labels = new ArrayList<>();
    private final List<ProgressBar> bars = new ArrayList<>();
    private final List<Runnable> perFrame = new ArrayList<>();

    private record Label(Component text, int x, int y, int color, boolean centered) {
    }

    private record ProgressBar(String file, int x, int y, int width) {
    }

    public BoardScreen() {
        super(Component.literal("VoiceBoard"));
    }

    private BoardConfig config() {
        return VoiceBoardClient.config();
    }

    private SoundPlayer player() {
        return VoiceBoardClient.player();
    }

    // ------------------------------------------------------------------ Aufbau

    @Override
    protected void init() {
        build();
    }

    private void rebuild() {
        clearWidgets();
        build();
    }

    private void build() {
        labels.clear();
        bars.clear();
        perFrame.clear();

        panelWidth = Math.min(width - 16, 400);
        left = (width - panelWidth) / 2;
        top = 6;

        // Reiter
        Tab[] tabs = Tab.values();
        int tabWidth = (panelWidth - (tabs.length - 1) * 3) / tabs.length;
        for (int i = 0; i < tabs.length; i++) {
            Tab t = tabs[i];
            int x = left + i * (tabWidth + 3);
            Button b = addRenderableWidget(Button.builder(Component.literal(t.label), btn -> switchTab(t))
                    .bounds(x, top, tabWidth, 20).build());
            b.active = t != tab;
            if (t == tab) {
                activeTabX = x;
                activeTabWidth = tabWidth;
            }
        }

        int contentY = top + 28;
        int bottomY = height - 26;

        switch (tab) {
            case SOUNDS -> buildSounds(contentY, bottomY);
            case FILTER -> buildFilter(contentY);
            case LIBRARY -> buildLibrary(contentY, bottomY);
        }

        // Fußleiste
        int bw = (panelWidth - 4) / 2;
        addRenderableWidget(Button.builder(Component.literal("Sound-Ordner öffnen"), b -> openFolder(BoardConfig.soundFolder()))
                .bounds(left, bottomY, bw, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Fertig"), b -> closeScreen())
                .bounds(left + bw + 4, bottomY, bw, 20).build());
    }

    private void switchTab(Tab t) {
        tab = t;
        lastTab = t;
        scroll = 0;
        listening = NONE;
        rebuild();
    }

    // ------------------------------------------------------------ Soundeffekte

    private void buildSounds(int y, int bottomY) {
        BoardConfig config = config();
        int right = left + panelWidth;

        labels.add(new Label(Component.literal("Alle Sounds stoppen"), left, y + 6, WHITE, false));
        addRenderableWidget(Button.builder(Component.literal("Stopp"), b -> player().stopAll())
                .bounds(right - 80 - 4 - 60, y, 60, 20).build());
        addRenderableWidget(Button.builder(keyLabel(config.stopAllKey, listening == STOP_ALL), b -> startListening(STOP_ALL))
                .bounds(right - 80, y, 80, 20).build());
        y += 24;

        addRenderableWidget(new PercentSlider(left, y, panelWidth, 20, "Lautstärke für andere", config.masterVolume, v -> {
            config.masterVolume = v;
            config.markDirty();
        }));
        y += 24;

        int half = (panelWidth - 4) / 2;
        addRenderableWidget(Button.builder(onOff("Selbst hören", config.hearSelf), b -> {
            config.hearSelf = !config.hearSelf;
            config.save();
            b.setMessage(onOff("Selbst hören", config.hearSelf));
        }).bounds(left, y, half, 20).build());
        addRenderableWidget(new PercentSlider(left + half + 4, y, half, 20, "Mithören", config.monitorVolume, v -> {
            config.monitorVolume = v;
            config.markDirty();
        }));
        y += 28;

        List<BoardConfig.SoundEntry> sounds = config.sounds;
        int listY = y + 14;
        int rowHeight = 24;
        int rows = Math.max(1, (bottomY - 4 - listY) / rowHeight);
        clampScroll(sounds.size(), rows);

        labels.add(new Label(Component.literal("Sounds (" + sounds.size() + ")").withStyle(ChatFormatting.BOLD, ChatFormatting.UNDERLINE),
                left + panelWidth / 2, y, WHITE, true));
        addScrollButtons(y - 3, sounds.size(), rows);

        if (sounds.isEmpty()) {
            labels.add(new Label(Component.literal("Noch keine Sounds."), left + panelWidth / 2, listY + 6, GRAY, true));
            labels.add(new Label(Component.literal("Lege .mp3/.wav-Dateien in den Sound-Ordner"), left + panelWidth / 2, listY + 20, GRAY, true));
            labels.add(new Label(Component.literal("und füge sie unter „Bibliothek“ hinzu."), left + panelWidth / 2, listY + 32, GRAY, true));
            return;
        }

        for (int i = scroll; i < Math.min(sounds.size(), scroll + rows); i++) {
            buildSoundRow(sounds.get(i), i, listY + (i - scroll) * rowHeight);
        }
    }

    private void buildSoundRow(BoardConfig.SoundEntry entry, int index, int y) {
        BoardConfig config = config();
        int right = left + panelWidth;

        int deleteX = right - 20;
        int editX = deleteX - 24;
        int sliderWidth = 64;
        int sliderX = editX - 4 - sliderWidth;
        int keyWidth = 80;
        int keyX = sliderX - 4 - keyWidth;
        int nameX = left + 24;
        int nameWidth = keyX - 6 - nameX;

        Button play = addRenderableWidget(Button.builder(Component.literal("▶"), b -> player().toggle(entry))
                .bounds(left, y, 20, 20).build());
        perFrame.add(() -> {
            String symbol = player().isLoading(entry.file) ? "…" : player().isPlaying(entry.file) ? "■" : "▶";
            play.setMessage(Component.literal(symbol));
        });

        labels.add(new Label(Component.literal(fit(entry.name, nameWidth)), nameX, y + 6, WHITE, false));
        bars.add(new ProgressBar(entry.file, nameX, y + 17, nameWidth));

        addRenderableWidget(Button.builder(keyLabel(entry.key, listening == index), b -> startListening(index))
                .bounds(keyX, y, keyWidth, 20).build());

        addRenderableWidget(new PercentSlider(sliderX, y, sliderWidth, 20, "", entry.volume, v -> {
            entry.volume = v;
            config.markDirty();
        }));

        addRenderableWidget(Button.builder(Component.literal("✎"), b -> minecraft.gui.setScreen(new RenameScreen(this, entry)))
                .bounds(editX, y, 20, 20).build());

        addRenderableWidget(Button.builder(Component.literal("✖").withStyle(ChatFormatting.RED), b -> {
            player().stop(entry.file);
            config.sounds.remove(entry);
            config.save();
            rebuild();
        }).bounds(deleteX, y, 20, 20).build());
    }

    // ------------------------------------------------------------- Voicefilter

    private void buildFilter(int y) {
        BoardConfig config = config();

        labels.add(new Label(Component.literal("Voicefilter").withStyle(ChatFormatting.BOLD, ChatFormatting.UNDERLINE),
                left + panelWidth / 2, y, WHITE, true));
        y += 14;

        FilterType[] types = FilterType.values();
        int cols = 4;
        int bw = (panelWidth - (cols - 1) * 4) / cols;
        for (int i = 0; i < types.length; i++) {
            FilterType type = types[i];
            boolean selected = config.filter == type;
            int x = left + (i % cols) * (bw + 4);
            int yy = y + (i / cols) * 24;
            Button b = addRenderableWidget(Button.builder(Component.literal(selected ? "✔ " + type.label : type.label), btn -> {
                config.filter = type;
                config.save();
                rebuild();
            }).bounds(x, yy, bw, 20).build());
            b.active = !selected;
        }
        y += ((types.length + cols - 1) / cols) * 24 + 4;

        addRenderableWidget(new PercentSlider(left, y, panelWidth, 20, "Stärke", config.filterStrength, v -> {
            config.filterStrength = v;
            config.markDirty();
        }));
        y += 24;

        addRenderableWidget(Button.builder(onOff("Sounds senden, wenn stumm", config.playWhileMuted), b -> {
            config.playWhileMuted = !config.playWhileMuted;
            config.save();
            b.setMessage(onOff("Sounds senden, wenn stumm", config.playWhileMuted));
        }).bounds(left, y, panelWidth, 20).build());
        y += 30;

        int cx = left + panelWidth / 2;
        labels.add(new Label(Component.literal("Der Filter verändert nur deine Stimme,"), cx, y, GRAY, true));
        labels.add(new Label(Component.literal("die Soundboard-Sounds bleiben unverändert."), cx, y + 12, GRAY, true));
        labels.add(new Label(Component.literal("Andere Spieler brauchen nur Simple Voice Chat."), cx, y + 30, GRAY, true));
    }

    // -------------------------------------------------------------- Bibliothek

    private void buildLibrary(int y, int bottomY) {
        BoardConfig config = config();
        List<String> files = scanFolder();

        int half = (panelWidth - 4) / 2;
        addRenderableWidget(Button.builder(Component.literal("Neu laden"), b -> {
            player().clearCache();
            rebuild();
        }).bounds(left, y, half, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Alle hinzufügen"), b -> {
            for (String f : files) {
                if (!config.contains(f)) {
                    config.sounds.add(new BoardConfig.SoundEntry(f, BoardConfig.stripExtension(f)));
                }
            }
            config.save();
            rebuild();
        }).bounds(left + half + 4, y, half, 20).build());
        y += 30;

        int listY = y + 14;
        int rowHeight = 22;
        int rows = Math.max(1, (bottomY - 4 - listY) / rowHeight);
        clampScroll(files.size(), rows);

        labels.add(new Label(Component.literal("Dateien im Sound-Ordner (" + files.size() + ")").withStyle(ChatFormatting.BOLD, ChatFormatting.UNDERLINE),
                left + panelWidth / 2, y, WHITE, true));
        addScrollButtons(y - 3, files.size(), rows);

        if (files.isEmpty()) {
            labels.add(new Label(Component.literal("Der Ordner ist leer."), left + panelWidth / 2, listY + 6, GRAY, true));
            labels.add(new Label(Component.literal("Klick auf „Sound-Ordner öffnen“, lege .mp3/.wav-"), left + panelWidth / 2, listY + 20, GRAY, true));
            labels.add(new Label(Component.literal("Dateien hinein und drück dann „Neu laden“."), left + panelWidth / 2, listY + 32, GRAY, true));
            return;
        }

        int buttonWidth = 110;
        for (int i = scroll; i < Math.min(files.size(), scroll + rows); i++) {
            String file = files.get(i);
            int rowY = listY + (i - scroll) * rowHeight;
            boolean added = config.contains(file);
            labels.add(new Label(Component.literal(fit(file, panelWidth - buttonWidth - 8)), left, rowY + 6, WHITE, false));
            Button b = addRenderableWidget(Button.builder(Component.literal(added ? "✔ Hinzugefügt" : "Hinzufügen"), btn -> {
                config.sounds.add(new BoardConfig.SoundEntry(file, BoardConfig.stripExtension(file)));
                config.save();
                rebuild();
            }).bounds(left + panelWidth - buttonWidth, rowY, buttonWidth, 20).build());
            b.active = !added;
        }
    }

    private List<String> scanFolder() {
        Path folder = BoardConfig.soundFolder();
        try {
            Files.createDirectories(folder);
            try (Stream<Path> stream = Files.list(folder)) {
                return stream.filter(Files::isRegularFile)
                        .map(p -> p.getFileName().toString())
                        .filter(AudioLoader::isSupported)
                        .sorted(String.CASE_INSENSITIVE_ORDER)
                        .toList();
            }
        } catch (Exception e) {
            VoiceBoardClient.LOGGER.error("Konnte Sound-Ordner nicht lesen", e);
            return List.of();
        }
    }

    // ------------------------------------------------------------------ Helfer

    private void clampScroll(int total, int rows) {
        scroll = Math.max(0, Math.min(scroll, total - rows));
    }

    private void addScrollButtons(int y, int total, int rows) {
        if (total <= rows) {
            return;
        }
        int right = left + panelWidth;
        Button up = addRenderableWidget(Button.builder(Component.literal("▲"), b -> {
            scroll--;
            rebuild();
        }).bounds(right - 42, y, 20, 14).build());
        up.active = scroll > 0;
        Button down = addRenderableWidget(Button.builder(Component.literal("▼"), b -> {
            scroll++;
            rebuild();
        }).bounds(right - 20, y, 20, 14).build());
        down.active = scroll + rows < total;
    }

    private static Component onOff(String label, boolean on) {
        return Component.literal(label + ": ").append(on
                ? Component.literal("An").withStyle(ChatFormatting.GREEN)
                : Component.literal("Aus").withStyle(ChatFormatting.RED));
    }

    private static Component keyLabel(BoardConfig.KeyBind bind, boolean listening) {
        if (listening) {
            return Component.literal("> ").append(Component.literal("Taste?").withStyle(ChatFormatting.UNDERLINE))
                    .append(" <").withStyle(ChatFormatting.YELLOW);
        }
        MutableComponent name = VoiceBoardClient.keyName(bind).copy();
        return bind.isBound() ? name : name.withStyle(ChatFormatting.GRAY);
    }

    /** Kürzt Text mit "…", damit er in die gegebene Breite passt. */
    private String fit(String text, int maxWidth) {
        if (maxWidth <= 0) return "";
        if (font.width(Component.literal(text)) <= maxWidth) return text;
        String s = text;
        while (!s.isEmpty() && font.width(Component.literal(s + "…")) > maxWidth) {
            s = s.substring(0, s.length() - 1);
        }
        return s + "…";
    }

    private void startListening(int target) {
        listening = target;
        rebuild();
    }

    private BoardConfig.KeyBind listeningBind() {
        if (listening == STOP_ALL) return config().stopAllKey;
        if (listening >= 0 && listening < config().sounds.size()) return config().sounds.get(listening).key;
        return null;
    }

    private void closeScreen() {
        config().save();
        minecraft.gui.setScreen(null);
    }

    private static void openFolder(Path folder) {
        try {
            Files.createDirectories(folder);
            String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
            String path = folder.toAbsolutePath().toString();
            ProcessBuilder pb;
            if (os.contains("win")) {
                pb = new ProcessBuilder("explorer", path);
            } else if (os.contains("mac")) {
                pb = new ProcessBuilder("open", path);
            } else {
                pb = new ProcessBuilder("xdg-open", path);
            }
            pb.start();
        } catch (Exception e) {
            VoiceBoardClient.LOGGER.error("Konnte Ordner nicht öffnen: {}", folder, e);
            VoiceBoardClient.notifyPlayer("Ordner: " + folder.toAbsolutePath());
        }
    }

    // ------------------------------------------------------------- Eingaben

    @Override
    public boolean keyPressed(KeyEvent keyEvent) {
        BoardConfig.KeyBind bind = listeningBind();
        if (bind != null) {
            if (keyEvent.isEscape()) {
                bind.clear();
            } else {
                InputConstants.Key key = InputConstants.getKey(keyEvent);
                bind.type = key.getType().name();
                bind.code = key.getValue();
            }
            listening = NONE;
            config().save();
            rebuild();
            return true;
        }
        if (keyEvent.isEscape()) {
            closeScreen();
            return true;
        }
        return super.keyPressed(keyEvent);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (listening != NONE) {
            listening = NONE;
            rebuild();
            return true;
        }
        return super.mouseClicked(event, doubleClick);
    }

    // Absichtlich ohne @Override: falls sich die Signatur ändert, kompiliert die Mod trotzdem
    // (dann funktioniert nur das Mausrad nicht, die ▲▼-Knöpfe aber schon).
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (tab == Tab.FILTER || scrollY == 0) {
            return false;
        }
        scroll += scrollY > 0 ? -1 : 1;
        rebuild();
        return true;
    }

    // Spiel im Einzelspieler nicht pausieren, damit der Sprachchat weiterläuft.
    public boolean isPauseScreen() {
        return false;
    }

    // ------------------------------------------------------------- Zeichnen

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        for (Runnable r : perFrame) {
            r.run();
        }

        super.extractRenderState(g, mouseX, mouseY, delta);

        // Linie unter dem aktiven Reiter
        g.fill(activeTabX + 8, top + 21, activeTabX + activeTabWidth - 8, top + 23, WHITE);

        for (Label label : labels) {
            if (label.centered()) {
                g.centeredText(font, label.text(), label.x(), label.y(), label.color());
            } else {
                g.text(font, label.text(), label.x(), label.y(), label.color(), true);
            }
        }

        for (ProgressBar bar : bars) {
            float progress = player().progress(bar.file());
            if (progress >= 0F) {
                g.fill(bar.x(), bar.y(), bar.x() + bar.width(), bar.y() + 2, 0x60FFFFFF);
                g.fill(bar.x(), bar.y(), bar.x() + Math.round(bar.width() * progress), bar.y() + 2, 0xFF55FF55);
            }
        }
    }
}
